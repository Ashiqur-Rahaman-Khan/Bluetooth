package com.topgearproject.org.bluetoothdatatransfer;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.ParcelUuid;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private static final String TAG = "info_mainAciviy: ";
    private static final int REQUEST_CODE = 1;
    private static final UUID MY_UUID =
            UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");
    TextView tv;
    ListView lv;
    BluetoothAdapter mBleAdapter;
    ArrayAdapter<String> listAdapter;
    Set<BluetoothDevice> pairedDevice;
    private OutputStream outStream;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        if (mBleAdapter == null) {
            Toast.makeText(getApplicationContext(), "Bletooth is not supported.", Toast.LENGTH_SHORT).show();
            Log.i(TAG, "Blueooth not supported.");
            finish();
        }
        if (!(mBleAdapter.isEnabled())) {
            turnOnBluetooth();
        }
        pairedDevice = getPairedDevices();
        if (pairedDevice.size() > 0) {
            for (BluetoothDevice devices : pairedDevice) {
                listAdapter.add(devices.getName() + "\n" + devices.getAddress());
            }
        }
        lv.setAdapter(listAdapter);
    }

    private void turnOnBluetooth() {
        Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        startActivityForResult(enableIntent, REQUEST_CODE);
    }

    private void init() {

        tv = (TextView) findViewById(R.id.textView);
        lv = (ListView) findViewById(R.id.listView);
        listAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1);
        mBleAdapter = BluetoothAdapter.getDefaultAdapter();
        lv.setOnItemClickListener(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_CANCELED) {
            Toast.makeText(getApplicationContext(), "Bluetooth must be enabled to continue", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    public Set<BluetoothDevice> getPairedDevices() {
        Set<BluetoothDevice> bondedDevices = mBleAdapter.getBondedDevices();
        return bondedDevices;
    }

    @Override
    protected void onResume() {
        super.onResume();
        lv.setAdapter(listAdapter);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
       Object[] o = pairedDevice.toArray();
        BluetoothDevice selectedDevice = (BluetoothDevice) o[i];
        ConnectThread connectThread = new ConnectThread(selectedDevice);
        connectThread.start();

    }
    private class ConnectThread extends Thread {

        private final BluetoothSocket mmSocket;
        private final BluetoothDevice mmDevice;

        public ConnectThread(BluetoothDevice device) {

            BluetoothSocket tmp = null;
            mmDevice = device;

            try {
                tmp = device.createRfcommSocketToServiceRecord(MY_UUID);
            } catch (IOException e) {
                Log.i(TAG, "get socket failed");

            }
            mmSocket = tmp;
        }

        public void run() {
            // Cancel discovery because it will slow down the connection
            mBleAdapter.cancelDiscovery();
            Log.i(TAG, "connect - run");
            try {

                mmSocket.connect();
                outStream = mmSocket.getOutputStream();
                SendData sentData = new SendData();
                sentData.sendMessage();
                Log.i(TAG, "connect - succeeded");
            } catch (IOException connectException) {
                Log.i(TAG, "connect failed");
                try {
                    mmSocket.close();
                } catch (IOException closeException) {
                }
                return;
            }
        }

        // Will cancel an in-progress connection, and close the socket
        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) {
            }
        }

    }

    private  class SendData extends Thread{

        public void sendMessage(){

            try {
                Bitmap bm = BitmapFactory.decodeResource(getResources(), R.drawable.white);
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bm.compress(Bitmap.CompressFormat.JPEG, 100,baos); //bm is the bitmap object
                byte[] b = baos.toByteArray();
                Toast.makeText(getBaseContext(), String.valueOf(b.length), Toast.LENGTH_SHORT).show();
                outStream.write(b);
                outStream.flush();
            } catch (IOException e) {
            }
        }

    }
}
